#!/bin/bash
# GPMftpDAC_by_date.bash  -- Downloads dated GPM data files from NASA ftp.

# STEP 1. Usage; warning.

DEFAULT_DIR_PREFIX=/home/synrad/data/gpm/dpr
#DBG +
# DEFAULT_DIR_PREFIX=/home/fallout/1/ar28471/Bash_code
#DBG - 

if (test $# -lt 3) then
  echo "GPMftpDAC_by_date usage: The script downloads GPM data files of a particular day from NASA ftp."
  echo "It takes 3 or 4 parameters:  Year(YYYY) Month(MM) Day(DD) </full/path/to/existing/dir>"
  echo "If 4th param is absent, default location will be created: " $DEFAULT_DIR_PREFIX"/<YYYY>/<MM>/<DD>/"
  echo "If 4th param is present it should be a full path to the existing directory."
  echo "NOTE:  /home/data/synrad/gpm should NEVER be used as destination."
  echo "BEWARE: No checking of date parameters correctness is done."
  exit
elif  (test $# -eq 4) then
    if [ ! -d $4 ] ; then
      echo "GPMftpDAC_by_date error: Only EXISTING dir can be entered." && exit 
	else 
		DESTINATION_DIR=$4
		cd $DESTINATION_DIR
		CURRENT_DIR=`pwd`
		if [ "$CURRENT_DIR" == "/home/data/synrad/gpm" ]
#  This testing becomes kind of irrelevant when running from DAC. Left intact just in case of future move back to GSWR cluster.
			then
				echo "GPMftpDAC_by_date error: Not allowed to use $CURRENT_DIR. It will cause problems for GPM Translation."
				exit 
			else
			    DESTINATION_DIR=$CURRENT_DIR
		fi
		year=$1
		month=$2
		day=$3
    fi

elif (test $# -gt 4) then
    echo "GPMftpDAC_by_date error: Wrong number of parameters. To see usage type script-name w/o params"
    exit
else    # only 3 params 
  year=$1
  month=$2
  day=$3
  DESTINATION_DIR=$DEFAULT_DIR_PREFIX/${year}/${month}/${day}
fi

#DBG +
# echo DESTINATION_DIR is $DESTINATION_DIR
# exit
#DBG -

# Step 2. Check the machine name; set up the hardcoded values.
MACHINE_NAME=`uname -n`
TARG_MACHINE=gswrds001
if [ $MACHINE_NAME != $TARG_MACHINE ]
then
  echo Sorry, this script runs only on gpmts1. You are trying to run it on $MACHINE_NAME
fi
echo "The machine is right: $MACHINE_NAME"  > /dev/null   #DBG

ftp_server="arthurhou.pps.eosdis.nasa.gov"
user_id="art.manwelyan@ll.mit.edu"
ftp_password=$user_id
echo "user_id and ftp_password are:"          > /dev/null   #DBG
echo $user_id  $ftp_password                  > /dev/null   #DBG

#Step 3. Create destination dir;  ftp connect, mget the data.
mkdir -p $DESTINATION_DIR

ftp -inv $ftp_server << geek
quote USER $user_id
quote PASS $ftp_password
lcd $DESTINATION_DIR
cd gpmdata/${year}/${month}/${day}/radar
mget 2A.GPM.DPR.V*
geek

echo "Finished step3"          > /dev/null   #DBG
echo "GPMftpDAC_by_date success: GPM data for " $year $month $day " is downloaded to " $DESTINATION_DIR

