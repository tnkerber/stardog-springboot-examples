#!/usr/bin/bash
# IMERGftps_DAC_by_date.bash

# STEP 1. Usage; warning. Create destination dir locally when all is fine.

 DEFAULT_DIR_PREFIX=/home/xfer/gpm/imrg
#DBG +
# DEFAULT_DIR_PREFIX=/home/fallout/1/ar28471/Bash_code
#DBG - 

if (test $# -lt 3) then
  echo "IMERGftps_DAC_by_date usage: The script downloads IMERG data files of a particular day from NASA ftp."
  echo "It takes 3 or 4 parameters:  Year(YYYY) Month(MM) Day(DD) </full/path/to/existing/dir>"
  echo "If 4th param is absent, default location will be created: " $DEFAULT_DIR_PREFIX"/<YYYY><MM><DD>/"
  echo "If 4th param is present it should be a full path to the existing directory."
  echo "BEWARE: No checking of date parameters correctness is done."
  exit
elif  (test $# -eq 4) then
    if [ ! -d $4 ] ; then
      echo "IMERGftps_DAC_by_date error: Only EXISTING dir can be entered." && exit 
    else 
		DESTINATION_DIR=$4
		cd $DESTINATION_DIR
		year=$1
		month=$2
		day=$3
    fi

elif (test $# -gt 4) then
    echo "IMERGftps_DAC_by_date error: Wrong number of parameters. To see usage type script-name w/o params"
    exit
else    # only 3 params 
  year=$1
  month=$2
  day=$3
  SUBDIR=/$year$month$day/
  DESTINATION_DIR=$DEFAULT_DIR_PREFIX$SUBDIR
  mkdir -p $DESTINATION_DIR
fi


#DBG +
 echo DESTINATION_DIR is $DESTINATION_DIR
#DBG -

# Step 2. Check the machine name; set up the hardcoded values.
MACHINE_NAME=`uname -n`
if [ $MACHINE_NAME != gpmds1 ] ; then
  echo Sorry, this script runs only on gpmds1. You are trying to run it on $MACHINE_NAME
  exit
fi
echo "The machine is right: $MACHINE_NAME"  #DBG   > /dev/null   #DBG

ftp_server="jsimpsonftps.pps.eosdis.nasa.gov"
user_id="art.manwelyan@ll.mit.edu"
ftp_password=$user_id
echo "user_id and ftp_password are:"    #DBG      > /dev/null   #DBG
echo $user_id  $ftp_password            #DBG      > /dev/null   #DBG
echo "ftp_server is "  ${ftp_server}            #DBG      > /dev/null   #DBG


#Step 3. lftp connect; use settings file;  mget the data.

lftp -u ${user_id},${ftp_password}   ${ftp_server}  <<- DOWNLOAD
  source /home/gpm/lftp.ssl.config
  lcd $DESTINATION_DIR
  cd /data/imerg/late/${year}${month}/
  mget 3B-HHR-L.MS.MRG.3IMERG.${year}${month}${day}*
DOWNLOAD

echo "Finished step 3"     #DBG     > /dev/null   #DBG
echo "IMERGftps_DAC_by_date success: IMERG data for " $year $month $day " is downloaded to " $DESTINATION_DIR

