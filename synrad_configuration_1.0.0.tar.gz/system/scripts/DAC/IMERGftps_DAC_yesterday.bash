#!/usr/bin/bash
#  IMERGftps_DAC_yesterday.bash    -- Downloads dated IMERG data files from NASA ftps.

# Step 0. Constants.

DEFAULT_DIR_PREFIX=/home/xfer/gpm/imrg
#DBG +
# DEFAULT_DIR_PREFIX=/home/fallout/1/ar28471/Bash_code
#DBG - 
MACHINE_NAME=`uname -n`

ftp_server="jsimpsonftps.pps.eosdis.nasa.gov"
user_id="art.manwelyan@ll.mit.edu"
ftp_password=$user_id
echo "user_id and ftp_password are:"   #  > /dev/null   #DBG
echo $user_id  $ftp_password           #  > /dev/null   #DBG
echo "ftp_server is "  ${ftp_server}            #DBG      > /dev/null   #DBG

# Step 1. Usage.
if (test $# -gt 0) then
  echo "IMERGftps_DAC_yesterday usage: The script downloads IMERG *late* data files of yesterday from NASA ftp."
  echo "It takes NO parameters.  Desitnation location is" $DEFAULT_DIR_PREFIX"/<YYYYMMDD>/"
  exit
fi 

# Step 2. Check the machine name; set up the hardcoded values.
if [ $MACHINE_NAME != gpmds1 ]
then
  echo Sorry, this script runs only on gpmds1. You are trying to run it on $MACHINE_NAME
fi
echo "The machine is right: $MACHINE_NAME"                   #  > /dev/null   #DBG

# Step 3. Date defining for dir; creating this dir; cd to there.
year=`date -d yesterday +%Y`
month=`date -d yesterday +%m`
day=`date -d yesterday +%d`
SUBDIR=/$year$month$day/
DESTINATION_DIR=$DEFAULT_DIR_PREFIX$SUBDIR
echo  $DESTINATION_DIR                                #  > /dev/null   #DBG
mkdir -p $DESTINATION_DIR


# Step 4. lftp connect; use settings file;  mget the data.

lftp -u ${user_id},${ftp_password}   ${ftp_server}  <<- DOWNLOAD
  source /home/gpm/lftp.ssl.config
  lcd $DESTINATION_DIR
  cd /data/imerg/late/${year}${month}/
  mget 3B-HHR-L.MS.MRG.3IMERG.${year}${month}${day}*
DOWNLOAD

echo "Finished step 4"     #DBG     > /dev/null   #DBG
echo "IMERGftps_DAC_by_date success: IMERG data for " $year $month $day " is downloaded to " $DESTINATION_DIR
 

