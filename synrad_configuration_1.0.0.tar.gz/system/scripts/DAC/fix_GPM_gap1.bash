#!/bin/bash
# fix_GPM_gap1.bash
./GPMftpDAC_by_date.bash 2019 10 03
./GPMftpDAC_by_date.bash 2019 10 04
./GPMftpDAC_by_date.bash 2019 10 05
./GPMftpDAC_by_date.bash 2019 10 06
./GPMftpDAC_by_date.bash 2019 10 07
./GPMftpDAC_by_date.bash 2019 10 08
./GPMftpDAC_by_date.bash 2019 10 09
./GPMftpDAC_by_date.bash 2019 10 10
./GPMftpDAC_by_date.bash 2019 10 11
./GPMftpDAC_by_date.bash 2019 10 12
./GPMftpDAC_by_date.bash 2019 10 13
./GPMftpDAC_by_date.bash 2019 10 14

