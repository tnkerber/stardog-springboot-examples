#!/bin/bash
export SCRIPT_HOME=/home/synrad/sw/synrad/system/scripts/DAC
export LOGS_HOME=/home/synrad/data/gpm/logs
$SCRIPT_HOME/GPMftpDAC_by_date.bash `date -d "-3 day" +"%Y %m %d"` > $LOGS_HOME/GPM_ftp_`date +%Y%m%d_%H%M%S`.log

