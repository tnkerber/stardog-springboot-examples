#!/usr/bin/bash
/home/gpm/IMERGftps_DAC_yesterday.bash  > /home/xfer/gpm/logs/IMERG_ftps_`date +%Y%m%d_%H%M%S`.log

