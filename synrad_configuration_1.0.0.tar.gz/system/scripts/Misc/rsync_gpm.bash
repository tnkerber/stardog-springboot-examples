#!/usr/bin/bash
# Process GPM data files daily.
cd /tmp/GPM
year=`date -d "-3 day"  +%Y`
month=`date -d "-3 day" +%m`
day=`date -d "-3 day"  +%d`
rsync  /data/incoming/GPM/$year/$month/$day/radar/*   .

