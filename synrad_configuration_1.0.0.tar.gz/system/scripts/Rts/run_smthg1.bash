#!/usr/bin/bash
#===============================================================================
#
#   (c) Copyright, 2019 Massachusetts Institute of Technology.
#
#===============================================================================
# run_smthg.bash 
# Test script running infinite loop and printing time every 15 sec

while [ 1 ]; do
  date
  sleep 15
done

