#!/usr/bin/bash

tdy=`date +%y%m%d`

cd /home/logs/synrad/gswrm001/"$tdy"
grep "Opened output file" WxArchiverMT_*.log > ./WxArchiverMT_"$tdy".skim
grep "\[ERR\]" WxArchiverMT_*.log > ./WxArchiverMT_"$tdy".ERR.skim
if [ ! -s ./WxArchiverMT_"$tdy".ERR.skim ] ; then
  rm ./WxArchiverMT_"$tdy".ERR.skim
fi

cd /home/logs/synrad/gswrm002/"$tdy"
grep "Opened output file" WxArchiverMT_*.log > ./WxArchiverMT_"$tdy".skim
grep "\[ERR\]" WxArchiverMT_*.log > ./WxArchiverMT_"$tdy".ERR.skim
if [ ! -s ./WxArchiverMT_"$tdy".ERR.skim ] ; then
  rm ./WxArchiverMT_"$tdy".ERR.skim
fi
