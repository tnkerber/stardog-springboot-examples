#!/usr/bin/bash    

#!/bin/bash
#while true
#do
#    if mountpoint -q /home/synrad
#        then
#
#		node=`hostname`
#    	   	cd /home/synrad/sw/synrad/system/scripts/Svd
#    		conda activate supervisor
#    		supervisord -c ./$node.svd.conf
#            break
#        fi
#    sleep 10
#done


#while ! [ -f /home/synrad ] ; do
#    sleep 1
#done

 node=`hostname` 
    cd /home/synrad/sw/synrad/system/scripts/Svd 
    conda activate supervisor
    supervisord -c ./$node.svd.conf
   
