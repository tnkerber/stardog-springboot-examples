#!/usr/bin/bash
#===============================================================================
#
#   (c) Copyright, 2019 Massachusetts Institute of Technology.
#
#===============================================================================
# updt_restart_Svd_node.bash script.
# Stops supervisord on current node; reads it config file; starts it again.

m=`hostname`


if [ $# -gt 0 ] 
then
  echo USAGE: updt_restart_Svd_node.bash runs without parameters
  echo "It stops supervisord on current node; reads it config file; starts it again"
exit
fi

echo You are about to restart supervisord on $m. Is this the intended node?
read -r -p "Are you sure? [y/N] " response
response=${response,,}    # tolower
if [[ ! "$response" =~ ^(yes|y)$ ]]
then
  exit
fi

cat $LOGS_HOME/supervisor/$m.pid | xargs kill -s SIGHUP
echo Update and restart succeeded.
