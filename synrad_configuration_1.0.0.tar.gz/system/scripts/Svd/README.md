Info can change without updating this file.

This dir (/home/sw_synrad/synrad/system/scripts/Svd ) is for everything related to Supervisord.

Command to activate conda environment:
conda activate supervisord

<node-name>.svd.conf -- config file to use with supervisord ON MACHINE <node-name>
Supervisor .log files and .pid files are in $LOGS_HOME/supervisor/

Example of starting the daemon on a server  <node-name> :
supervisord -c <node-name>.svd.conf 

Supervisord  works in conjunction with ssh tunnels created by tunl.bash script. See
$SW_HOME/synrad/Web/Instruc101.html for more info on concepts and details.

In /home/sw_synrad/synrad/system/scripts/Rts there are 3 relevant scripts :
start_supervisord_everywhere.bash -- takes 1 param: file with list of nodes
stop_supervisord_everywhere.bash   -- same
set_Svd_tnls.bash - sets tunnels for all nodes involved (gswr<s,m,l or xl><NNN>,
gswrds1-2, gswrgs1-2, gswrls1).
The above scripts (start_supervisord_everywhere.bash and set_Svd_tnls.bash) must be executed once,
when the synrad RTS cluster starts.

Scripts start_supervisord_everywhere.bash and stop... are usually use $PARAM_PATH/system/Svd_nodes_list.txt.
This parameter file has a content of $PARAM_PATH/system/host_list.txt file with addition of gswrls1 node.

set_Svd_tnls.bash does not set a tunnel for gswrls1 (because this node is used as the
"host" of tunnels -- it's complicated, but this is how it should be.) 
Port 9033 is designated for gswrls1. Ports 9023 to 9028  are currently unused.

